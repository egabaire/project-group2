<!DOCTYPE html>

<html lang="en">

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/Controlpanel.css">
	<title>Controlpanel</title>
</head>

<body>

		<div class="container">	
				<div class="nesteddiv">				
						<div class="img-controlpanel">
						
						<img class="imgControlpanel" src="img/image3.jpg" alt="Username">
						
						</div>
						
						<div class="textprofilepic">
						<p class="textpic">"Username/Admin"</p>
						</div>
							
					
					<div class="Controlpanel-buttons"> <button type="button"><p class="buttonstxt">Write post</p></button>
					
					</div>
					
					
					<div class="Controlpanel-buttons"> <button type="button"><p class="buttonstxt">Followers</p></button>
					
					</div>
					
					<div class="Controlpanel-buttons"> <button type="button"><p class="buttonstxt">View activity</p></button>
					
					</div>
					
					<div class="Controlpanel-buttons"> <button type="button"><p class="buttonstxt">Logout</p></button>
					
					</div>
					
				</div>
						
				<div class="boxwithchoice">
					
					<p class="txtboxchoice">Depending on what the user/admin chooses the choices will appear here.loremlore
					mloremlorloremloremloremloremloremloremloremloremloremloloremloremloremlorloremloremloremlo
					remloremloremloremloremloremaaaaa<br>aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaalolor<br>emloremloremlorloremloremloremloremloremloremloremloremloremlo</p>
						
				</div>
					
		</div>
				

</body>