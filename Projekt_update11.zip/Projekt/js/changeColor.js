 function message()
 {
      alert("Please Login first!");
 }

            function changeColor()
            {
                var color = document.getElementById('thumb');
                if(color.style.color=="green")
                {
                    color.style.color = "black";
                }

                else if(color.style.color=="black")
                {
                    color.style.color = "green";
                }
                

            }