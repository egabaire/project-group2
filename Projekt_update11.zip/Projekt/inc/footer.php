<footer id="footer">
			<p>© 2020 Project Group 2</p>
	</footer>
		
	</body>
	
<html>